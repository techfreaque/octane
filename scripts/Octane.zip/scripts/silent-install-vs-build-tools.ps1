./windows_dependencies/vs_build_tools.exe --add Microsoft.VisualStudio.Workload.VCTools --add Microsoft.VisualStudio.Component.VC.CLI.Support --add Microsoft.VisualStudio.Component.Windows10SDK --add Microsoft.VisualStudio.Workload.UniversalBuildTools

