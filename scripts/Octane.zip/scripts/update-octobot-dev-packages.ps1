.venv\Scripts\Activate.ps1
.\.venv\Scripts\python.exe -m pip install -r octobot-packages/OctoBot-Backtesting/dev_requirements.txt
.\.venv\Scripts\python.exe -m pip install -r octobot-packages/OctoBot-Commons/dev_requirements.txt
.\.venv\Scripts\python.exe -m pip install -r octobot-packages/OctoBot-evaluators/dev_requirements.txt
.\.venv\Scripts\python.exe -m pip install -r octobot-packages/OctoBot-Services/dev_requirements.txt
.\.venv\Scripts\python.exe -m pip install -r octobot-packages/OctoBot-Tentacles-Manager/dev_requirements.txt
.\.venv\Scripts\python.exe -m pip install -r octobot-packages/OctoBot-Trading/dev_requirements.txt
.\.venv\Scripts\python.exe -m pip install -r octobot-packages/OctoBot/dev_requirements.txt

