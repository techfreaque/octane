DailyTradingMode is a **low risk versatile trading mode** that reacts only the its state changes to 
a state that is different from the previous one and that is not NEUTRAL.

![eagle](https://i.ytimg.com/an_webp/tc-p93x5rPQ/mqdefault_6s.webp?du=3000&sqp=CNig8PIF&rs=AOn4CLBbI7vfF2hXRmkgMF6rCikDy9T5CA "Eagle")

![eagle2](img/Trading/Mode/daily_trading_mode/resources/eagle.png "Eagle2")

When triggered for a given symbol, it will cancel previously created (and unfilled) orders 
and create new ones according to its new state.

DailyTradingMode will consider every compatible strategy and average their evaluation to create
each state.